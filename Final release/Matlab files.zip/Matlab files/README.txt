This folder contains the following Matlab scripts:
1D Model: one dimensional model (run Model_1D.m)
2D Model: two dimensional model used for the simulations of exercise 5 to 9 (run Model_2D.m)
Orthogonality: used for exercise 3 and 10
